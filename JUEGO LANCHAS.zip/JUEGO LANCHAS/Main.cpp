#include "lanchitas.h"
#include <stdio.h>
#include <Windows.h>

void calcularElNitro(lanchitas& lanchita) {
	int op;
	std::cin >> op;

	if (op == 1) {
		int dadoN;
		dadoN = rand() % 2;
		Sleep(1000);
		std::cout << lanchita.getName() << "Has usado el Nitro, tirare un dado, si sale 1 tu velocidad se multiplicara, si sale 0 se reducira tu velocidad a la mitad " << std::endl;
		std::cout << "El dado a sido lanzado y has sacado un " << dadoN << std::endl;

		if (dadoN == 0) {
			Sleep(1000);
			lanchita.printNitroOFF();
			std::cout << "Tu velocidad se a reducido a la mitad y ahora es de " << lanchita.getVelocidad() << std::endl;
			lanchita.printNoQuedaNitro();
		}

		if (dadoN == 1) {
			Sleep(1000);
			lanchita.printNitroON();
			std::cout << "El nitro se a activado, tu velocidad se a multiplicado por dos " << std::endl;
			lanchita.printNoQuedaNitro();
		}
	}

	if (op == 2) {
		std::cout << "Te has reservado el nitro vas a " << lanchita.getVelocidad() << std::endl;
	}

}

int main() {
	int turno = 5;
	int dadoPartida;
	srand(time(NULL));

	lanchitas lanchita1("ALVARO RECIO", 0, 0, 1);
	lanchitas lanchita2("ILARIO EL DE LOS CEMENTOS", 0, 0, 1);

	std::cout << "Bienvenidos a la carrera de lanchas, se disputaran el titulo el corredor " << lanchita1.getName() << " contra " << lanchita2.getName() << std::endl;
	Sleep(1000);
	std::cout << "Acordaros que no se permite comida de fuera, si quiere comprar, la tienda esta en la planta 0" << std::endl;
	Sleep(1000);
	std::cout << "Guarden asiento que la carrera empieza en..." << std::endl;
	Sleep(2000);

	std::cout << "---------------------------------------------------5---------------------------------------------------" << std::endl;
	Sleep(1000);
	std::cout << "---------------------------------------------------4---------------------------------------------------" << std::endl;
	Sleep(1000);
	std::cout << "---------------------------------------------------3---------------------------------------------------" << std::endl;
	Sleep(1000);
	std::cout << "---------------------------------------------------2---------------------------------------------------" << std::endl;
	Sleep(1000);
	std::cout << "---------------------------------------------------1---------------------------------------------------" << std::endl;
	Sleep(1000);
	std::cout << "---------------------------------------------------YA!---------------------------------------------------" << std::endl;
	Sleep(2000);


	for (size_t i = 0; i < 5; i++)
	{
		dadoPartida = rand() % 6 + 1;
		turno = turno - 1;
		lanchita1.printDistancia(dadoPartida);
		if (lanchita1.getNitro() == 1) {
			std::cout << lanchita1.getName() << " Quiere utilizar el nitro? " << std::endl;
			std::cout << "1. Activo el Nitro " << std::endl;
			std::cout << "2. No lo utilizo " << std::endl;
			std::cout << "\n" << std::endl;
			Sleep(1000);
			calcularElNitro(lanchita1);
			Sleep(1000);
		}

		std::cout << "Te quedan " << turno << " turnos" << std::endl;
		Sleep(500);
		std::cout << "\n" << std::endl;
		Sleep(1000);

		if (turno == 0) {
			std::cout << "No te quedan turnos, lo siento" << std::endl;
			Sleep(1000);
		}

		dadoPartida = rand() % 6 + 1;
		lanchita2.printDistancia(dadoPartida);
		if (lanchita2.getNitro() == 1) {
			std::cout << lanchita2.getName() << " Quiere utilizar el nitro? " << std::endl;
			std::cout << "1. Activo el Nitro " << std::endl;
			std::cout << "2. No lo utilizo " << std::endl;
			std::cout << "\n" << std::endl;
			Sleep(1000);
			calcularElNitro(lanchita2);
			Sleep(1000);
		}

		std::cout << "Te quedan " << turno << " turnos" << std::endl;
		Sleep(500);
		std::cout << "\n" << std::endl;
		Sleep(1000);

		if (turno == 0) {
			std::cout << "No te quedan turnos, lo siento" << std::endl;
			Sleep(1000);
		}
	}

	if (lanchita1.getdistancia() > lanchita2.getdistancia()) {
		std::cout << lanchita1.getName() << " Has ganado la carrera " << std::endl;
	}
	else {
		std::cout << lanchita2.getName() << " Has ganado la carrera " << std::endl;
	}

}




