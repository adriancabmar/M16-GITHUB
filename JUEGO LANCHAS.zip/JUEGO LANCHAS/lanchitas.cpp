#include "lanchitas.h"
#include <stdio.h>
#include <Windows.h>

//CONSTRUCTOR
lanchitas::lanchitas(std::string pName, int pVel, int pDist, int pNitro) {
	name = pName;
	velocidad = pVel;
	distancia = pDist;
	nitro = pNitro;
}

//GETTERS
std::string lanchitas::getName() {
	return name;
}

int lanchitas::getVelocidad() {
	return velocidad;
}

int lanchitas::getdistancia() {
	return distancia;
}

int lanchitas::getNitro() {
	return nitro;
}



//SETTERS
void lanchitas::setName(std::string pName) {
	name = pName;
}

void lanchitas::setVelocidad(int pVel) {
	velocidad = pVel;
}

void lanchitas::setdistancia(int pDist) {
	distancia = pDist;
}

void lanchitas::setNitro(int pNitro) {
	nitro = pNitro;
}



//METODOS PROPIOS 

void lanchitas::printNoQuedaNitro() { //no funciona
	int noNitro = 0;
	nitro = nitro - 1;
	std::cout << name << " Te has quedado sin nitro, solo se puede usar una vez y ya no puedes usarlo mas" << std::endl;
	nitro = noNitro;
}

void lanchitas::printNitroON() {
	velocidad = (velocidad * 2);
}

void lanchitas::printNitroOFF() {
	velocidad = (velocidad / 2);
}


void lanchitas::printDistancia(int pDado) {
	velocidad = velocidad + pDado;
	distancia = distancia + (velocidad * 100);

	std::cout << name << " has tirado el dado y has sacado un " << pDado << std::endl;
	std::cout << "Tu nueva velocidad es de " << velocidad << std::endl;
	std::cout << "Tu nueva distancia es de " << distancia << std::endl;

}




