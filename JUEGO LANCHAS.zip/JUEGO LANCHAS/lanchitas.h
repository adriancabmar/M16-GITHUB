#pragma once

#include <iostream>
#include <stdio.h>
#include <Windows.h>

class lanchitas
{
private:
	std::string name; //variable nombre
	int velocidad; //variable velocidad
	int distancia; //variable distancia recorrida
	int nitro; //variable nitro


public:
	//constructor
	lanchitas(std::string pName, int pVel, int pDist, int pNitro);


	//getters
	std::string getName(); //variable conseguir nombre
	int getVelocidad(); //variable conseguir velocidad
	int getdistancia(); //variable conseguir distancia recorrida
	int getNitro(); //variable conseguir nitro
	int getTurno();

	//setters
	void setName(std::string pName); //variable colocar el nombre
	void setVelocidad(int pVel); //variable colocar velocidad
	void setdistancia(int pDist); //variable colocar distancia recorrida
	void setNitro(int pNitro); //variable colocar nitro
	void setTurno(int pTurno);

	//metodos propios

	void printTurno();
	void printfinCarrera(int turno);
	void printDistancia(int pDado);
	void printVelocidad();
	void printNitroON();
	void printNitroOFF();
	void printNoQuedaNitro();
};
